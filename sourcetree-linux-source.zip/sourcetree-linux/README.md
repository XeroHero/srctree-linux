# SourceTree Linux

A SourceTree-like Git GUI client for Linux, built with Electron, React, and Vite.

## Features

- **Multi-tab Repository Support**: Open and manage multiple repositories simultaneously
- **Visual Commit History**: Browse commits with visual branch graph
- **Working Copy Management**: Stage, unstage, and discard file changes
- **Diff Viewer**: View unified diffs with syntax highlighting
- **Branch Operations**: Create, switch, merge, and delete branches
- **Remote Operations**: Push, pull, and fetch from remotes
- **Stash Management**: Save and apply stashes
- **Tag Management**: Create and view tags
- **Bookmark Persistence**: Your recent repositories are saved

## Technology Stack

- **Electron 33**: Cross-platform desktop application framework
- **React 18**: Modern UI library
- **Vite 6**: Fast build tool and dev server
- **simple-git 3.x**: Pure Node.js Git library (no native bindings)
- **electron-builder**: Package and distribute the application

## Installation

```bash
cd sourcetree-linux
npm install
```

## Development

Run the React development server:
```bash
npm run dev
```

In another terminal, run Electron:
```bash
npm run electron:dev
```

## Building

Build the React application:
```bash
npm run build
```

Build the Electron AppImage:
```bash
npm run dist
```

The AppImage will be created in the `release/` directory.

## Usage

### Opening a Repository

1. Launch SourceTree Linux
2. Click "Open Existing" to browse for a Git repository
3. Or click "Clone" to clone a remote repository
4. Or click "Create New" to initialize a new Git repository

### Working with Files

1. Click "Working Copy" in the sidebar
2. Stage files by clicking "Stage" next to each file
3. Unstage files by clicking "Unstage"
4. Discard changes with the "Discard" button
5. Commit staged files using the "Commit" button in the toolbar

### Branch Management

1. Create new branches with the "Branch" button
2. Switch branches by clicking on them in the sidebar
3. Merge branches with the "Merge" button

### Remote Operations

- **Push**: Push commits to remote repository
- **Pull**: Pull changes from remote repository
- **Fetch**: Fetch latest changes without merging

## Architecture

### IPC Security Pattern

The application uses Electron's `contextBridge` for secure IPC communication:
- **main.js**: Main Electron process with Git operations
- **preload.js**: Secure bridge exposing Git API to renderer
- **React UI**: Renderer process using exposed API

### Git Operations

All Git operations are performed using `simple-git` in the main process:
- Repository status and logs
- File staging and committing
- Branch operations
- Remote operations
- Stash operations
- Tag operations

## Project Structure

```
sourcetree-linux/
├── main.js                 # Electron main process
├── preload.js              # IPC bridge
├── index.html              # Entry HTML
├── package.json            # Dependencies and scripts
├── vite.config.js          # Vite configuration
└── src/
    ├── main.jsx            # React entry point
    ├── App.jsx             # Main app component
    ├── App.css             # Styles
    └── components/
        ├── WelcomeScreen.jsx
        ├── RepositoryView.jsx
        ├── Sidebar.jsx
        ├── Toolbar.jsx
        ├── CommitHistory.jsx
        ├── BranchGraph.jsx
        ├── WorkingCopy.jsx
        ├── DiffViewer.jsx
        ├── StatusBar.jsx
        └── dialogs/
            ├── BranchDialog.jsx
            ├── MergeDialog.jsx
            ├── StashDialog.jsx
            ├── PushDialog.jsx
            ├── PullDialog.jsx
            ├── TagDialog.jsx
            └── CommitDialog.jsx
```

## Version

1.0.0 - Initial release (2025-03-31)

## License

MIT
